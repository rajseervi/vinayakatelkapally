"use client";
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { VisuallyEnhancedDashboardLayout } from '@/components/ModernLayout';
import ModernThemeProvider from '@/contexts/ModernThemeContext';



import { db } from '@/firebase/config';
import { 
  collection, 
  doc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  serverTimestamp,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  DocumentSnapshot
} from 'firebase/firestore';
import { useRouter } from 'next/navigation';
import { Party, PartyFormData, PartyFilters, PartyStatistics } from '@/types/party';
import { partyService } from '@/services/partyService';
import { useAuth } from '@/contexts/AuthContext';
import {
  Container,
  Typography,
  Paper,
  Box,
  TextField,
  Button,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Alert,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  InputAdornment,
  Card,
  CardContent,
  CardActions,
  Avatar,
  Tooltip,
  Fade,
  Skeleton,
  useTheme,
  alpha,
  Stack,
  Divider,
  TablePagination,
  TableSortLabel,
  Fab,
  Zoom,
  Checkbox,
  Menu,
  ListItemIcon,
  ListItemText,
  Badge,
  LinearProgress,
  Snackbar,
  ToggleButton,
  ToggleButtonGroup,
  Breadcrumbs,
  Link,
  SpeedDial,
  SpeedDialAction,
  SpeedDialIcon,
  Autocomplete,
  Switch,
  FormControlLabel,
  Collapse,
  useMediaQuery,
  ButtonGroup
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  Person as PersonIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  LocationOn as LocationIcon,
  Business as BusinessIcon,
  FilterList as FilterIcon,
  ViewList as ViewListIcon,
  ViewModule as ViewModuleIcon,
  History as HistoryIcon,
  LocalOffer as DiscountIcon,
  Download as DownloadIcon,
  Upload as UploadIcon,
  MoreVert as MoreVertIcon,
  Visibility as VisibilityIcon,
  VisibilityOff as VisibilityOffIcon,
  TrendingUp as TrendingUpIcon,
  AccountBalance as AccountBalanceIcon,
  CreditCard as CreditCardIcon,
  Group as GroupIcon,
  Star as StarIcon,
  StarBorder as StarBorderIcon,
  Sort as SortIcon,
  Refresh as RefreshIcon,
  FileDownload as FileDownloadIcon,
  FileUpload as FileUploadIcon,
  Settings as SettingsIcon,
  Analytics as AnalyticsIcon,
  Home as HomeIcon,
  NavigateNext as NavigateNextIcon,
  CheckCircle as CheckCircleIcon,
  Cancel as CancelIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon
} from '@mui/icons-material';

// Enhanced interfaces
interface Category {
  id: string;
  name: string;
}

interface EnhancedPartyFilters extends PartyFilters {
  sortBy?: 'name' | 'createdAt' | 'outstandingBalance' | 'creditLimit';
  sortOrder?: 'asc' | 'desc';
  showInactive?: boolean;
  favoriteOnly?: boolean;
}

interface BulkAction {
  id: string;
  label: string;
  icon: React.ReactNode;
  action: (selectedIds: string[]) => void;
  color?: 'primary' | 'secondary' | 'error' | 'warning' | 'info' | 'success';
}

function PartiesPage() {
  const router = useRouter();
  const theme = useTheme();
  const { user } = useAuth();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  // Core state
  const [parties, setParties] = useState<Party[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [statistics, setStatistics] = useState<PartyStatistics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  
  // UI state
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('cards');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(12);
  const [orderBy, setOrderBy] = useState<keyof Party>('name');
  const [order, setOrder] = useState<'asc' | 'desc'>('asc');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  
  // Selection and bulk operations
  const [selectedParties, setSelectedParties] = useState<Set<string>>(new Set());
  const [bulkActionAnchor, setBulkActionAnchor] = useState<null | HTMLElement>(null);
  
  // Dialogs
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedParty, setSelectedParty] = useState<Party | null>(null);
  const [openDiscountDialog, setOpenDiscountDialog] = useState(false);
  const [openImportDialog, setOpenImportDialog] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState<Partial<PartyFormData>>({
    name: '',
    email: '',
    phone: '',
    address: '',
    businessType: 'Customer',
    isActive: true,
    categoryDiscounts: {},
    productDiscounts: {}
  });
  
  // Filter state
  const [filters, setFilters] = useState<EnhancedPartyFilters>({
    searchTerm: '',
    businessType: '',
    isActive: true,
    showInactive: false,
    favoriteOnly: false,
    sortBy: 'name',
    sortOrder: 'asc'
  });
  
  // Discount dialog state
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [discountValue, setDiscountValue] = useState<number>(0);
  const [products, setProducts] = useState<{id: string, name: string}[]>([]);
  
  // Notification state
  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: 'success' | 'error' | 'warning' | 'info';
  }>({
    open: false,
    message: '',
    severity: 'info'
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [filteredParties, setFilteredParties] = useState<Party[]>([]);

  // Enhanced data fetching with better error handling and statistics
  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Fetch parties using the basic Firebase approach for now
      const partiesCollection = collection(db, 'parties');
      const partiesSnapshot = await getDocs(partiesCollection);
      const partiesList = partiesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        categoryDiscounts: doc.data().categoryDiscounts || {},
        productDiscounts: doc.data().productDiscounts || {}
      } as Party));
      
      setParties(partiesList);
      
      // Calculate basic statistics
      const stats: PartyStatistics = {
        totalParties: partiesList.length,
        activeParties: partiesList.filter(p => p.isActive !== false).length,
        inactiveParties: partiesList.filter(p => p.isActive === false).length,
        totalOutstanding: partiesList.reduce((sum, p) => sum + (p.outstandingBalance || 0), 0),
        totalCreditLimit: partiesList.reduce((sum, p) => sum + (p.creditLimit || 0), 0),
        businessTypeBreakdown: {
          B2B: partiesList.filter(p => p.businessType === 'B2B').length,
          B2C: partiesList.filter(p => p.businessType === 'B2C').length,
          Supplier: partiesList.filter(p => p.businessType === 'Supplier').length,
          Customer: partiesList.filter(p => p.businessType === 'Customer').length,
        },
        topParties: partiesList
          .filter(p => (p.outstandingBalance || 0) > 0)
          .sort((a, b) => (b.outstandingBalance || 0) - (a.outstandingBalance || 0))
          .slice(0, 5)
          .map(p => ({
            partyId: p.id!,
            partyName: p.name,
            totalTransactions: 0,
            totalAmount: 0,
            outstandingBalance: p.outstandingBalance || 0
          }))
      };
      
      setStatistics(stats);
      
      // Fetch categories and products
      const [categoriesSnapshot, productsSnapshot] = await Promise.all([
        getDocs(collection(db, 'categories')),
        getDocs(collection(db, 'products'))
      ]);
      
      const categoriesList = categoriesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Category));
      
      const productsList = productsSnapshot.docs.map(doc => ({
        id: doc.id,
        name: doc.data().name
      }));
      
      setCategories(categoriesList);
      setProducts(productsList);
      
      if (!loading) {
        showSnackbar('Data refreshed successfully', 'success');
      }
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to fetch data. Please try again later.');
      showSnackbar('Failed to load data', 'error');
    } finally {
      setLoading(false);
    }
  }, [loading]);

  // Refresh data function
  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  }, [fetchData]);

  // Initial data fetch
  useEffect(() => {
    fetchData();
  }, []);

  // Snackbar helper
  const showSnackbar = (message: string, severity: 'success' | 'error' | 'warning' | 'info') => {
    setSnackbar({ open: true, message, severity });
  };

  // Export functionality
  const handleExport = async () => {
    try {
      const dataToExport = parties.map(party => ({
        name: party.name,
        email: party.email || '',
        phone: party.phone || '',
        address: party.address || '',
        businessType: party.businessType,
        isActive: party.isActive,
        creditLimit: party.creditLimit || 0,
        outstandingBalance: party.outstandingBalance || 0,
        categoryDiscounts: JSON.stringify(party.categoryDiscounts || {}),
        createdAt: party.createdAt
      }));
      
      const csv = [
        Object.keys(dataToExport[0]).join(','),
        ...dataToExport.map(row => Object.values(row).join(','))
      ].join('\n');
      
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `parties_export_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      showSnackbar('Parties exported successfully', 'success');
    } catch (error) {
      showSnackbar('Failed to export parties', 'error');
    }
  };

  // Selection handlers
  const handleSelectAll = () => {
    if (selectedParties.size === filteredParties.length) {
      setSelectedParties(new Set());
    } else {
      setSelectedParties(new Set(filteredParties.map(p => p.id!)));
    }
  };

  const handleSelectParty = (partyId: string) => {
    const newSelection = new Set(selectedParties);
    if (newSelection.has(partyId)) {
      newSelection.delete(partyId);
    } else {
      newSelection.add(partyId);
    }
    setSelectedParties(newSelection);
  };

  // Enhanced filtering with multiple criteria
  useEffect(() => {
    let filtered = [...parties];

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(party => 
        party.name.toLowerCase().includes(query) ||
        (party.email && party.email.toLowerCase().includes(query)) ||
        (party.phone && party.phone.toLowerCase().includes(query)) ||
        (party.address && party.address.toLowerCase().includes(query))
      );
    }

    // Business type filter
    if (filters.businessType) {
      filtered = filtered.filter(party => party.businessType === filters.businessType);
    }

    // Active/Inactive filter
    if (!filters.showInactive) {
      filtered = filtered.filter(party => party.isActive !== false);
    }

    setFilteredParties(filtered);
    setPage(0); // Reset to first page when filters change
  }, [searchQuery, parties, filters]);

  // Sorting function
  const handleRequestSort = (property: keyof Party) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  // Sort parties
  const sortedParties = useMemo(() => {
    return [...filteredParties].sort((a, b) => {
      if (orderBy === 'name') {
        return order === 'asc' 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      }
      if (orderBy === 'outstandingBalance') {
        const aBalance = a.outstandingBalance || 0;
        const bBalance = b.outstandingBalance || 0;
        return order === 'asc' ? aBalance - bBalance : bBalance - aBalance;
      }
      if (orderBy === 'creditLimit') {
        const aLimit = a.creditLimit || 0;
        const bLimit = b.creditLimit || 0;
        return order === 'asc' ? aLimit - bLimit : bLimit - aLimit;
      }
      return 0;
    });
  }, [filteredParties, order, orderBy]);

  // Paginated parties
  const paginatedParties = useMemo(() => {
    const startIndex = page * rowsPerPage;
    return sortedParties.slice(startIndex, startIndex + rowsPerPage);
  }, [sortedParties, page, rowsPerPage]);

  // Handle page change
  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  // Handle rows per page change
  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Get party initials for avatar
  const getPartyInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  // Get party avatar color
  const getPartyAvatarColor = (name: string) => {
    const colors = [
      theme.palette.primary.main,
      theme.palette.secondary.main,
      theme.palette.error.main,
      theme.palette.warning.main,
      theme.palette.info.main,
      theme.palette.success.main,
    ];
    const index = name.length % colors.length;
    return colors[index];
  };

  const handleViewDetails = (id: string) => {
    router.push(`/parties/${id}`);
  };

  const handlePartyNameClick = (partyId: string) => {
    router.push(`/parties/${partyId}/history`);
  };

  const handleAddParty = () => {
    setSelectedParty(null);
    setFormData({
      name: '',
      email: '',
      phone: '',
      address: '',
      businessType: 'Customer',
      isActive: true,
      categoryDiscounts: {},
      productDiscounts: {}
    });
    setOpenDialog(true);
  };

  const handleEditParty = (party: Party) => {
    setSelectedParty(party);
    setFormData({
      name: party.name,
      email: party.email,
      phone: party.phone,
      address: party.address,
      businessType: party.businessType,
      isActive: party.isActive,
      categoryDiscounts: party.categoryDiscounts || {},
      productDiscounts: party.productDiscounts || {}
    });
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSaveParty = async () => {
    try {
      setLoading(true);
      
      // Validate required fields
      if (!formData.name?.trim()) {
        showSnackbar('Party name is required', 'error');
        return;
      }
      
      // Clean and prepare data for Firebase
      const cleanedData = {
        name: formData.name || '',
        contactPerson: formData.contactPerson || '',
        email: formData.email || '',
        phone: formData.phone || '',
        address: formData.address || '',
        panNumber: formData.panNumber || '',
        businessType: formData.businessType || 'Customer',
        isActive: formData.isActive !== undefined ? formData.isActive : true,
        creditLimit: formData.creditLimit || 0,
        outstandingBalance: formData.outstandingBalance || 0,
        paymentTerms: formData.paymentTerms || '',
        preferredPaymentMethod: formData.preferredPaymentMethod || 'Cash',
        website: formData.website || '',
        bankDetails: formData.bankDetails || {},
        notes: formData.notes || '',
        tags: formData.tags || [],
        categoryDiscounts: formData.categoryDiscounts || {},
        productDiscounts: formData.productDiscounts || {},
        updatedAt: new Date().toISOString(),
        userId: user?.uid
      };
      
      if (selectedParty) {
        // Update existing party
        const partyRef = doc(db, 'parties', selectedParty.id!);
        await updateDoc(partyRef, cleanedData);
        
        // Update local state
        setParties(parties.map(p => 
          p.id === selectedParty.id ? { ...p, ...cleanedData } : p
        ));
        showSnackbar('Party updated successfully', 'success');
      } else {
        // Create new party
        const partiesCollection = collection(db, 'parties');
        const docRef = await addDoc(partiesCollection, {
          ...cleanedData,
          createdAt: new Date().toISOString()
        });
        
        // Add to local state
        setParties([...parties, {
          id: docRef.id,
          ...cleanedData
        } as Party]);
        showSnackbar('Party created successfully', 'success');
      }
      
      setOpenDialog(false);
      setError(null);
    } catch (err) {
      console.error('Error saving party:', err);
      setError('Failed to save party. Please try again.');
      showSnackbar('Failed to save party', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteParty = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this party?')) {
      try {
        setLoading(true);
        
        // Delete from Firebase
        const partyRef = doc(db, 'parties', id);
        await deleteDoc(partyRef);
        
        // Remove from local state
        setParties(parties.filter(p => p.id !== id));
        setError(null);
        showSnackbar('Party deleted successfully', 'success');
      } catch (err) {
        console.error('Error deleting party:', err);
        setError('Failed to delete party. Please try again.');
        showSnackbar('Failed to delete party', 'error');
      } finally {
        setLoading(false);
      }
    }
  };

  // Open discount dialog
  const handleAddDiscount = () => {
    setSelectedCategory('');
    setDiscountValue(0);
    setOpenDiscountDialog(true);
  };

  // Save discount
  const handleSaveDiscount = () => {
    if (!selectedCategory) return;
    
    setFormData({
      ...formData,
      categoryDiscounts: {
        ...formData.categoryDiscounts,
        [selectedCategory]: discountValue
      }
    });
    
    setOpenDiscountDialog(false);
  };

  // Remove discount
  const handleRemoveDiscount = (category: string) => {
    const updatedDiscounts = { ...formData.categoryDiscounts };
    delete updatedDiscounts[category];
    
    setFormData({
      ...formData,
      categoryDiscounts: updatedDiscounts
    });
  };

  // Render loading skeleton for cards
  const renderLoadingSkeleton = () => (
    <Grid container spacing={3}>
      {Array.from(new Array(6)).map((_, index) => (
        <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
          <Card sx={{ height: '100%' }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Skeleton variant="circular" width={48} height={48} sx={{ mr: 2 }} />
                <Box sx={{ flexGrow: 1 }}>
                  <Skeleton variant="text" width="80%" height={24} />
                  <Skeleton variant="text" width="60%" height={20} />
                </Box>
              </Box>
              <Skeleton variant="text" width="100%" height={20} sx={{ mb: 1 }} />
              <Skeleton variant="text" width="90%" height={20} sx={{ mb: 1 }} />
              <Skeleton variant="text" width="70%" height={20} />
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );

  // Enhanced party cards with better design
  const renderPartyCards = () => (
    <Fade in={!loading}>
      <Grid container spacing={3}>
        {paginatedParties.map((party) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={party.id}>
            <Card 
              sx={{ 
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                transition: 'all 0.3s ease-in-out',
                '&:hover': {
                  transform: 'translateY(-4px)',
                  boxShadow: theme.shadows[8],
                },
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                position: 'relative',
              }}
            >
              {/* Selection checkbox */}
              <Checkbox
                checked={selectedParties.has(party.id!)}
                onChange={() => handleSelectParty(party.id!)}
                sx={{
                  position: 'absolute',
                  top: 8,
                  right: 8,
                  zIndex: 1,
                  bgcolor: 'background.paper',
                  borderRadius: '50%',
                  '&:hover': {
                    bgcolor: alpha(theme.palette.primary.main, 0.1),
                  }
                }}
              />

              <CardContent sx={{ flexGrow: 1, p: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar
                    sx={{
                      bgcolor: getPartyAvatarColor(party.name),
                      width: 48,
                      height: 48,
                      mr: 2,
                      fontSize: '1.1rem',
                      fontWeight: 600,
                    }}
                  >
                    {getPartyInitials(party.name)}
                  </Avatar>
                  <Box sx={{ flexGrow: 1, minWidth: 0 }}>
                    <Typography
                      variant="h6"
                      sx={{
                        fontWeight: 600,
                        cursor: 'pointer',
                        color: 'primary.main',
                        '&:hover': {
                          textDecoration: 'underline',
                        },
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                      onClick={() => handlePartyNameClick(party.id!)}
                    >
                      {party.name}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Chip
                        label={party.businessType || 'Customer'}
                        size="small"
                        color={party.businessType === 'Supplier' ? 'secondary' : 'primary'}
                        variant="outlined"
                        sx={{ fontSize: '0.75rem' }}
                      />
                      {party.isActive === false && (
                        <Chip
                          label="Inactive"
                          size="small"
                          color="error"
                          variant="outlined"
                          sx={{ fontSize: '0.75rem' }}
                        />
                      )}
                    </Box>
                  </Box>
                </Box>

                <Stack spacing={1.5}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <EmailIcon sx={{ fontSize: 16, mr: 1, color: 'text.secondary' }} />
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                      }}
                    >
                      {party.email || 'No email'}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <PhoneIcon sx={{ fontSize: 16, mr: 1, color: 'text.secondary' }} />
                    <Typography variant="body2">
                      {party.phone || 'No phone'}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'flex-start' }}>
                    <LocationIcon sx={{ fontSize: 16, mr: 1, color: 'text.secondary', mt: 0.2 }} />
                    <Typography 
                      variant="body2" 
                      sx={{ 
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        display: '-webkit-box',
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: 'vertical',
                      }}
                    >
                      {party.address || 'No address'}
                    </Typography>
                  </Box>

                  {/* Financial info */}
                  {(party.outstandingBalance || party.creditLimit) && (
                    <Box>
                      <Divider sx={{ my: 1 }} />
                      <Grid container spacing={1}>
                        {party.outstandingBalance && (
                          <Grid item xs={6}>
                            <Typography variant="caption" color="text.secondary">
                              Outstanding
                            </Typography>
                            <Typography variant="body2" fontWeight="medium" color="error.main">
                              ₹{party.outstandingBalance.toLocaleString()}
                            </Typography>
                          </Grid>
                        )}
                        {party.creditLimit && (
                          <Grid item xs={6}>
                            <Typography variant="caption" color="text.secondary">
                              Credit Limit
                            </Typography>
                            <Typography variant="body2" fontWeight="medium" color="success.main">
                              ₹{party.creditLimit.toLocaleString()}
                            </Typography>
                          </Grid>
                        )}
                      </Grid>
                    </Box>
                  )}

                  {Object.keys(party.categoryDiscounts || {}).length > 0 && (
                    <Box>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                        <DiscountIcon sx={{ fontSize: 16, mr: 1, color: 'text.secondary' }} />
                        <Typography variant="body2" color="text.secondary">
                          Discounts
                        </Typography>
                      </Box>
                      <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                        {Object.entries(party.categoryDiscounts || {}).slice(0, 2).map(([category, discount]) => (
                          <Chip
                            key={category}
                            label={`${category}: ${discount}%`}
                            size="small"
                            variant="outlined"
                            sx={{ fontSize: '0.75rem' }}
                          />
                        ))}
                        {Object.keys(party.categoryDiscounts || {}).length > 2 && (
                          <Chip
                            label={`+${Object.keys(party.categoryDiscounts).length - 2} more`}
                            size="small"
                            variant="outlined"
                            sx={{ fontSize: '0.75rem' }}
                          />
                        )}
                      </Box>
                    </Box>
                  )}
                </Stack>
              </CardContent>
              
              <Divider />
              
              <CardActions sx={{ justifyContent: 'space-between', p: 2 }}>
                <Button 
                  size="small" 
                  onClick={() => handleViewDetails(party.id!)} 
                  startIcon={<ViewListIcon />}
                  variant="outlined"
                >
                  Details
                </Button>
                <Box>
                  <IconButton
                    size="small"
                    onClick={() => handleEditParty(party)}
                    color="primary"
                  >
                    <EditIcon />
                  </IconButton>
                  <IconButton
                    size="small"
                    onClick={() => handleDeleteParty(party.id!)}
                    color="error"
                  >
                    <DeleteIcon />
                  </IconButton>
                </Box>
              </CardActions>
            </Card>
          </Grid>
        ))}
        
        {paginatedParties.length === 0 && !loading && (
          <Grid item xs={12}>
            <Paper 
              sx={{ 
                p: 6, 
                textAlign: 'center',
                bgcolor: alpha(theme.palette.primary.main, 0.02),
                border: `2px dashed ${alpha(theme.palette.primary.main, 0.2)}`,
              }}
            >
              <BusinessIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
              <Typography variant="h6" color="text.secondary" gutterBottom>
                {searchQuery ? 'No parties found matching your search' : 'No parties yet'}
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                {searchQuery 
                  ? 'Try adjusting your search terms or clear the search to see all parties.'
                  : 'Get started by adding your first party to the system.'
                }
              </Typography>
              {!searchQuery && (
                <Button
                  variant="contained"
                  startIcon={<AddIcon />}
                  onClick={handleAddParty}
                  size="large"
                >
                  Add Your First Party
                </Button>
              )}
            </Paper>
          </Grid>
        )}
      </Grid>
    </Fade>
  );

  // Enhanced table view with selection
  const renderTableView = () => (
    <TableContainer component={Paper} sx={{ mt: 2 }}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell padding="checkbox">
              <Checkbox
                indeterminate={selectedParties.size > 0 && selectedParties.size < filteredParties.length}
                checked={filteredParties.length > 0 && selectedParties.size === filteredParties.length}
                onChange={handleSelectAll}
              />
            </TableCell>
            <TableCell>
              <TableSortLabel
                active={orderBy === 'name'}
                direction={orderBy === 'name' ? order : 'asc'}
                onClick={() => handleRequestSort('name')}
              >
                Name
              </TableSortLabel>
            </TableCell>
            <TableCell>Contact</TableCell>
            <TableCell>Business Type</TableCell>
            <TableCell>
              <TableSortLabel
                active={orderBy === 'outstandingBalance'}
                direction={orderBy === 'outstandingBalance' ? order : 'asc'}
                onClick={() => handleRequestSort('outstandingBalance')}
              >
                Outstanding
              </TableSortLabel>
            </TableCell>
            <TableCell>
              <TableSortLabel
                active={orderBy === 'creditLimit'}
                direction={orderBy === 'creditLimit' ? order : 'asc'}
                onClick={() => handleRequestSort('creditLimit')}
              >
                Credit Limit
              </TableSortLabel>
            </TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {paginatedParties.map((party) => (
            <TableRow key={party.id} hover selected={selectedParties.has(party.id!)}>
              <TableCell padding="checkbox">
                <Checkbox
                  checked={selectedParties.has(party.id!)}
                  onChange={() => handleSelectParty(party.id!)}
                />
              </TableCell>
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Avatar
                    sx={{
                      bgcolor: getPartyAvatarColor(party.name),
                      width: 32,
                      height: 32,
                      mr: 2,
                      fontSize: '0.875rem',
                    }}
                  >
                    {getPartyInitials(party.name)}
                  </Avatar>
                  <Box>
                    <Typography
                      sx={{
                        cursor: 'pointer',
                        color: 'primary.main',
                        fontWeight: 500,
                        '&:hover': {
                          textDecoration: 'underline',
                        },
                      }}
                      onClick={() => handlePartyNameClick(party.id!)}
                    >
                      {party.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {party.address && party.address.length > 30 
                        ? `${party.address.substring(0, 30)}...` 
                        : party.address || 'No address'
                      }
                    </Typography>
                  </Box>
                </Box>
              </TableCell>
              <TableCell>
                <Box>
                  <Typography variant="body2">
                    {party.email || '-'}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {party.phone || '-'}
                  </Typography>
                </Box>
              </TableCell>
              <TableCell>
                <Chip
                  label={party.businessType || 'Customer'}
                  size="small"
                  color={party.businessType === 'Supplier' ? 'secondary' : 'primary'}
                  variant="outlined"
                />
              </TableCell>
              <TableCell>
                <Typography 
                  variant="body2" 
                  color={party.outstandingBalance && party.outstandingBalance > 0 ? 'error.main' : 'text.secondary'}
                  fontWeight={party.outstandingBalance && party.outstandingBalance > 0 ? 'medium' : 'normal'}
                >
                  {party.outstandingBalance ? `₹${party.outstandingBalance.toLocaleString()}` : '-'}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="body2" color="success.main">
                  {party.creditLimit ? `₹${party.creditLimit.toLocaleString()}` : '-'}
                </Typography>
              </TableCell>
              <TableCell>
                <Chip
                  label={party.isActive === false ? 'Inactive' : 'Active'}
                  size="small"
                  color={party.isActive === false ? 'error' : 'success'}
                  variant="outlined"
                />
              </TableCell>
              <TableCell align="right">
                <IconButton
                  size="small"
                  onClick={() => handleViewDetails(party.id!)}
                  color="info"
                >
                  <ViewListIcon />
                </IconButton>
                <IconButton
                  size="small"
                  onClick={() => handleEditParty(party)}
                  color="primary"
                >
                  <EditIcon />
                </IconButton>
                <IconButton
                  size="small"
                  onClick={() => handleDeleteParty(party.id!)}
                  color="error"
                >
                  <DeleteIcon />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  return (
    <Container maxWidth="xl" sx={{ py: 3 }}>
        {/* Breadcrumbs */}
        <Breadcrumbs sx={{ mb: 2 }}>
          <Link color="inherit" href="/dashboard" sx={{ display: 'flex', alignItems: 'center' }}>
            <HomeIcon sx={{ mr: 0.5 }} fontSize="inherit" />
            Dashboard
          </Link>
          <Typography color="text.primary" sx={{ display: 'flex', alignItems: 'center' }}>
            <GroupIcon sx={{ mr: 0.5 }} fontSize="inherit" />
            Parties
          </Typography>
        </Breadcrumbs>

        {/* Header Section */}
        <Box sx={{ mb: 4 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
            <Box>
              <Typography variant="h4" sx={{ fontWeight: 700, mb: 1 }}>
                Parties Management
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Manage your customers and suppliers with advanced features
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Tooltip title="Refresh Data">
                <IconButton
                  onClick={handleRefresh}
                  disabled={refreshing}
                  sx={{
                    border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                    borderRadius: 1.5,
                  }}
                >
                  {refreshing ? <CircularProgress size={20} /> : <RefreshIcon />}
                </IconButton>
              </Tooltip>
              <Tooltip title="Export Data">
                <IconButton
                  onClick={handleExport}
                  sx={{
                    border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                    borderRadius: 1.5,
                  }}
                >
                  <FileDownloadIcon />
                </IconButton>
              </Tooltip>
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={handleAddParty}
                size="large"
                sx={{
                  borderRadius: 2,
                  px: 3,
                  py: 1.5,
                  fontWeight: 600,
                  textTransform: 'none',
                }}
              >
                Add Party
              </Button>
            </Box>
          </Box>

          {/* Search and Controls */}
          <Paper 
            sx={{ 
              p: 3, 
              mb: 3,
              border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
              borderRadius: 2,
            }}
          >
            <Grid container spacing={2} alignItems="center">
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  variant="outlined"
                  placeholder="Search parties by name, email, phone, or address..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon color="action" />
                      </InputAdornment>
                    ),
                    endAdornment: searchQuery && (
                      <InputAdornment position="end">
                        <IconButton
                          size="small"
                          onClick={() => setSearchQuery('')}
                          edge="end"
                        >
                          <ClearIcon />
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 2,
                    },
                  }}
                />
              </Grid>
              <Grid item xs={12} md={3}>
                <FormControl fullWidth>
                  <InputLabel>Business Type</InputLabel>
                  <Select
                    value={filters.businessType || ''}
                    label="Business Type"
                    onChange={(e) => setFilters({ ...filters, businessType: e.target.value })}
                  >
                    <MenuItem value="">All Types</MenuItem>
                    <MenuItem value="Customer">Customer</MenuItem>
                    <MenuItem value="Supplier">Supplier</MenuItem>
                    <MenuItem value="B2B">B2B</MenuItem>
                    <MenuItem value="B2C">B2C</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={3}>
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 1 }}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={filters.showInactive || false}
                        onChange={(e) => setFilters({ ...filters, showInactive: e.target.checked })}
                      />
                    }
                    label="Show Inactive"
                  />
                  <ToggleButtonGroup
                    value={viewMode}
                    exclusive
                    onChange={(_, newMode) => newMode && setViewMode(newMode)}
                    size="small"
                  >
                    <ToggleButton value="cards">
                      <ViewModuleIcon />
                    </ToggleButton>
                    <ToggleButton value="table">
                      <ViewListIcon />
                    </ToggleButton>
                  </ToggleButtonGroup>
                </Box>
              </Grid>
            </Grid>
          </Paper>

          {/* Bulk Actions Bar */}
          {selectedParties.size > 0 && (
            <Paper 
              sx={{ 
                p: 2, 
                mb: 3,
                bgcolor: alpha(theme.palette.primary.main, 0.1),
                border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
                borderRadius: 2,
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <Typography variant="body1" fontWeight="medium">
                  {selectedParties.size} parties selected
                </Typography>
                <ButtonGroup variant="outlined" size="small">
                  <Button startIcon={<CheckCircleIcon />} color="success">
                    Activate
                  </Button>
                  <Button startIcon={<CancelIcon />} color="warning">
                    Deactivate
                  </Button>
                  <Button startIcon={<DeleteIcon />} color="error">
                    Delete
                  </Button>
                </ButtonGroup>
              </Box>
            </Paper>
          )}

          {/* Enhanced Stats Cards */}
          <Grid container spacing={3} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                p: 3, 
                textAlign: 'center', 
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)} 0%, ${alpha(theme.palette.primary.main, 0.05)} 100%)`
              }}>
                <GroupIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
                <Typography variant="h4" color="primary" sx={{ fontWeight: 700 }}>
                  {statistics?.totalParties || parties.length}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Parties
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                p: 3, 
                textAlign: 'center', 
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                background: `linear-gradient(135deg, ${alpha(theme.palette.success.main, 0.1)} 0%, ${alpha(theme.palette.success.main, 0.05)} 100%)`
              }}>
                <CheckCircleIcon sx={{ fontSize: 40, color: 'success.main', mb: 1 }} />
                <Typography variant="h4" color="success.main" sx={{ fontWeight: 700 }}>
                  {statistics?.activeParties || parties.filter(p => p.isActive !== false).length}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Active Parties
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                p: 3, 
                textAlign: 'center', 
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                background: `linear-gradient(135deg, ${alpha(theme.palette.warning.main, 0.1)} 0%, ${alpha(theme.palette.warning.main, 0.05)} 100%)`
              }}>
                <AccountBalanceIcon sx={{ fontSize: 40, color: 'warning.main', mb: 1 }} />
                <Typography variant="h4" color="warning.main" sx={{ fontWeight: 700 }}>
                  ₹{(statistics?.totalOutstanding || 0).toLocaleString()}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Outstanding
                </Typography>
              </Card>
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                p: 3, 
                textAlign: 'center', 
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                background: `linear-gradient(135deg, ${alpha(theme.palette.info.main, 0.1)} 0%, ${alpha(theme.palette.info.main, 0.05)} 100%)`
              }}>
                <DiscountIcon sx={{ fontSize: 40, color: 'info.main', mb: 1 }} />
                <Typography variant="h4" color="info.main" sx={{ fontWeight: 700 }}>
                  {parties.filter(p => Object.keys(p.categoryDiscounts || {}).length > 0).length}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  With Discounts
                </Typography>
              </Card>
            </Grid>
          </Grid>
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>
            {error}
          </Alert>
        )}

        {/* Loading Progress */}
        {(loading || refreshing) && (
          <LinearProgress sx={{ mb: 2, borderRadius: 1 }} />
        )}

        {/* Content */}
        {loading ? (
          renderLoadingSkeleton()
        ) : (
          <>
            {viewMode === 'cards' ? renderPartyCards() : renderTableView()}
            
            {/* Pagination */}
            {sortedParties.length > 0 && (
              <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                <Paper sx={{ border: `1px solid ${alpha(theme.palette.divider, 0.1)}` }}>
                  <TablePagination
                    component="div"
                    count={sortedParties.length}
                    page={page}
                    onPageChange={handleChangePage}
                    rowsPerPage={rowsPerPage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    rowsPerPageOptions={[6, 12, 24, 48]}
                    labelRowsPerPage="Items per page:"
                  />
                </Paper>
              </Box>
            )}
          </>
        )}

        {/* Speed Dial for Mobile */}
        {isMobile && (
          <SpeedDial
            ariaLabel="Party actions"
            sx={{ position: 'fixed', bottom: 16, right: 16 }}
            icon={<SpeedDialIcon />}
          >
            <SpeedDialAction
              icon={<AddIcon />}
              tooltipTitle="Add Party"
              onClick={handleAddParty}
            />
            <SpeedDialAction
              icon={<FileDownloadIcon />}
              tooltipTitle="Export"
              onClick={handleExport}
            />
            <SpeedDialAction
              icon={<RefreshIcon />}
              tooltipTitle="Refresh"
              onClick={handleRefresh}
            />
          </SpeedDial>
        )}

        {/* Add/Edit Party Dialog */}
        <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
          <DialogTitle>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <PersonIcon />
              {selectedParty ? 'Edit Party' : 'Add New Party'}
            </Box>
          </DialogTitle>
          <DialogContent>
            <Box sx={{ mt: 2 }}>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    label="Party Name"
                    name="name"
                    fullWidth
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Email"
                    name="email"
                    type="email"
                    fullWidth
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Phone"
                    name="phone"
                    fullWidth
                    value={formData.phone}
                    onChange={handleInputChange}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormControl fullWidth>
                    <InputLabel>Business Type</InputLabel>
                    <Select
                      value={formData.businessType || 'Customer'}
                      label="Business Type"
                      onChange={(e) => setFormData({ ...formData, businessType: e.target.value as any })}
                    >
                      <MenuItem value="Customer">Customer</MenuItem>
                      <MenuItem value="Supplier">Supplier</MenuItem>
                      <MenuItem value="B2B">B2B</MenuItem>
                      <MenuItem value="B2C">B2C</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={12} md={6}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={formData.isActive !== false}
                        onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                      />
                    }
                    label="Active"
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    label="Address"
                    name="address"
                    fullWidth
                    multiline
                    rows={3}
                    value={formData.address}
                    onChange={handleInputChange}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Credit Limit"
                    name="creditLimit"
                    type="number"
                    fullWidth
                    value={formData.creditLimit || ''}
                    onChange={(e) => setFormData({ ...formData, creditLimit: Number(e.target.value) })}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                    }}
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <TextField
                    label="Outstanding Balance"
                    name="outstandingBalance"
                    type="number"
                    fullWidth
                    value={formData.outstandingBalance || ''}
                    onChange={(e) => setFormData({ ...formData, outstandingBalance: Number(e.target.value) })}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                    }}
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <Typography variant="h6">Category Discounts</Typography>
                    <Button 
                      size="small" 
                      startIcon={<AddIcon />}
                      onClick={handleAddDiscount}
                      variant="outlined"
                    >
                      Add Discount
                    </Button>
                  </Box>
                  
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {Object.entries(formData.categoryDiscounts || {}).map(([category, discount]) => (
                      <Chip 
                        key={category}
                        label={`${category}: ${discount}%`}
                        onDelete={() => handleRemoveDiscount(category)}
                        color="primary"
                        variant="outlined"
                      />
                    ))}
                    {Object.keys(formData.categoryDiscounts || {}).length === 0 && (
                      <Typography variant="body2" color="text.secondary" sx={{ p: 2, textAlign: 'center', width: '100%' }}>
                        No category discounts added yet
                      </Typography>
                    )}
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </DialogContent>
          <DialogActions sx={{ p: 3 }}>
            <Button onClick={handleCloseDialog}>Cancel</Button>
            <Button 
              onClick={handleSaveParty} 
              variant="contained"
              disabled={!formData.name || loading}
              startIcon={loading ? <CircularProgress size={20} /> : null}
            >
              {selectedParty ? 'Update' : 'Create'}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Add Category Discount Dialog */}
        <Dialog open={openDiscountDialog} onClose={() => setOpenDiscountDialog(false)} maxWidth="xs" fullWidth>
          <DialogTitle>Add Category Discount</DialogTitle>
          <DialogContent>
            <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 3 }}>
              <FormControl fullWidth>
                <InputLabel>Category</InputLabel>
                <Select
                  value={selectedCategory}
                  label="Category"
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  {categories.map((category) => (
                    <MenuItem 
                      key={category.id} 
                      value={category.name}
                      disabled={formData.categoryDiscounts?.[category.name] !== undefined}
                    >
                      {category.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <TextField
                label="Discount Percentage"
                type="number"
                fullWidth
                value={discountValue}
                onChange={(e) => setDiscountValue(Number(e.target.value))}
                InputProps={{
                  inputProps: { min: 0, max: 100, step: 0.1 },
                  endAdornment: <InputAdornment position="end">%</InputAdornment>,
                }}
                helperText="Enter discount percentage (0-100)"
              />
            </Box>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDiscountDialog(false)}>Cancel</Button>
            <Button 
              onClick={handleSaveDiscount} 
              variant="contained"
              disabled={!selectedCategory || discountValue < 0 || discountValue > 100}
            >
              Add Discount
            </Button>
          </DialogActions>
        </Dialog>

        {/* Snackbar for notifications */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={6000}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          <Alert 
            onClose={() => setSnackbar({ ...snackbar, open: false })} 
            severity={snackbar.severity}
            sx={{ width: '100%' }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
    </Container>
  );
}

export default function ModernPartiesPage() {
  return (
    <ModernThemeProvider>
      <VisuallyEnhancedDashboardLayout
        title="Parties"
        pageType="parties"
        enableVisualEffects={true}
        enableParticles={false}
      >
        <PartiesPage />
      </VisuallyEnhancedDashboardLayout>
    </ModernThemeProvider>
  );
}