"use client";

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  Container,
  Typography,
  Box,
  Button,
  CircularProgress,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Chip,
  Card,
  CardContent,
  Grid,
  Tooltip,
  useTheme,
  useMediaQuery,
  Divider,
  Stack
} from '@mui/material';
import {
  Add as AddIcon,
  Download as DownloadIcon,
  Visibility as VisibilityIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Receipt as ReceiptIcon,
  Person as PersonIcon,
  Dashboard as DashboardIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material';

import { VisuallyEnhancedDashboardLayout } from '@/components/ModernLayout';
import ModernThemeProvider from '@/contexts/ModernThemeContext';

import PageHeader from '@/components/PageHeader/PageHeader';
import { OrderService } from '@/services/orderService';
import { Order } from '@/types/order';
import { Party } from '@/types/party';
import ConfirmationDialog from '@/components/ConfirmationDialog';
import { useAuth } from '@/contexts/AuthContext';
import EnhancedPartySearch from '@/components/parties/EnhancedPartySearch';
import PendingOrdersManager from '@/components/Orders/PendingOrdersManager';
import CreateOrderForm from '@/components/Orders/CreateOrderForm';
function OrdersPage() {
  const router = useRouter();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const { currentUser } = useAuth();

  // State management for enhanced features
  const [selectedParty, setSelectedParty] = useState<Party | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editOrder, setEditOrder] = useState<Order | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Legacy state (keeping for compatibility)
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [orderToDelete, setOrderToDelete] = useState<string | null>(null);

  const handlePartySelect = (party: Party | null) => {
    setSelectedParty(party);
  };

  const handleCreateOrder = () => {
    setEditOrder(null);
    setShowCreateForm(true);
  };

  const handleEditOrder = (order: Order) => {
    setEditOrder(order);
    setShowCreateForm(true);
  };

  const handleViewOrder = (order: Order) => {
    router.push(`/orders/${order.id}`);
  };

  const handleFormSuccess = () => {
    setRefreshTrigger(prev => prev + 1);
    setSuccessMessage('Order saved successfully!');
  };

  const handleCreateNewParty = () => {
    router.push('/parties/new');
  };

  // Legacy functions for compatibility
  const fetchOrders = async () => {
    try {
      setLoading(true);
      const fetchedOrders = await OrderService.getAllOrders();
      setOrders(fetchedOrders);
    } catch (err: any) {
      console.error("Error fetching orders:", err);
      setError(err.message || "Failed to fetch orders.");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteClick = (orderId: string) => {
    setOrderToDelete(orderId);
    setDeleteConfirmOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (orderToDelete) {
      try {
        await OrderService.deleteOrder(orderToDelete);
        setSuccessMessage("Order deleted successfully!");
        setRefreshTrigger(prev => prev + 1);
      } catch (err: any) {
        console.error("Error deleting order:", err);
        setError(err.message || "Failed to delete order.");
      } finally {
        setDeleteConfirmOpen(false);
        setOrderToDelete(null);
      }
    }
  };

  const handleCancelDelete = () => {
    setDeleteConfirmOpen(false);
    setOrderToDelete(null);
  };

  if (!currentUser) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Card>
          <CardContent sx={{ textAlign: 'center', py: 6 }}>
            <Typography variant="h6" color="text.secondary">
              Please log in to access orders
            </Typography>
          </CardContent>
        </Card>
      </Container>
    );
  }

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: 'grey.50' }}>
        <Container maxWidth="xl" sx={{ py: 3 }}>
          {/* Enhanced Page Header */}
          <Card sx={{ mb: 3, boxShadow: theme.shadows[2] }}>
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <Box
                    sx={{
                      p: 1.5,
                      borderRadius: 2,
                      bgcolor: 'primary.main',
                      color: 'white',
                    }}
                  >
                    <ReceiptIcon fontSize="large" />
                  </Box>
                  <Box>
                    <Typography 
                      variant={isMobile ? "h5" : "h4"} 
                      fontWeight="bold" 
                      color="text.primary"
                    >
                      Enhanced Order Management
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Advanced party search with comprehensive order tracking and management
                    </Typography>
                  </Box>
                </Box>
                
                {!isMobile && (
                  <Box sx={{ display: 'flex', gap: 1 }}>
                    <Tooltip title="Refresh">
                      <IconButton 
                        onClick={() => setRefreshTrigger(prev => prev + 1)}
                        sx={{ 
                          bgcolor: 'action.hover',
                          '&:hover': { bgcolor: 'action.selected' }
                        }}
                      >
                        <RefreshIcon />
                      </IconButton>
                    </Tooltip>
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      onClick={handleCreateOrder}
                      size="large"
                      sx={{ borderRadius: 2, px: 3 }}
                    >
                      Create Order
                    </Button>
                  </Box>
                )}
              </Box>

              {/* Quick Stats or Info */}
              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <PersonIcon color="primary" />
                    <Typography variant="body2" color="text.secondary">
                      {selectedParty 
                        ? `Selected: ${selectedParty.name}` 
                        : 'No party selected'
                      }
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <DashboardIcon color="primary" />
                    <Typography variant="body2" color="text.secondary">
                      Full-featured order management system
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12} md={4}>
                  {isMobile && (
                    <Button
                      variant="contained"
                      startIcon={<AddIcon />}
                      onClick={handleCreateOrder}
                      fullWidth
                      sx={{ borderRadius: 2 }}
                    >
                      Create Order
                    </Button>
                  )}
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Alerts */}
          {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
          {successMessage && <Alert severity="success" sx={{ mb: 2 }}>{successMessage}</Alert>}

          {/* Enhanced Party Search - Full Width Top Position */}
          <EnhancedPartySearch
            userId={currentUser.uid}
            onPartySelect={handlePartySelect}
            selectedParty={selectedParty}
            placeholder="🔍 Search parties by name, phone, email, or GSTIN for order creation..."
            showCreateButton={true}
            onCreateNew={handleCreateNewParty}
            showFilters={true}
          />

          {/* Selected Party Info */}
          {selectedParty && (
            <Card sx={{ mb: 3, border: '2px solid', borderColor: 'primary.main' }}>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Box>
                    <Typography variant="h6" color="primary" fontWeight="bold">
                      Selected Party: {selectedParty.name}
                    </Typography>
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 2, mt: 1 }}>
                      {selectedParty.phone && (
                        <Typography variant="body2" color="text.secondary">
                          📞 {selectedParty.phone}
                        </Typography>
                      )}
                      {selectedParty.email && (
                        <Typography variant="body2" color="text.secondary">
                          ✉️ {selectedParty.email}
                        </Typography>
                      )}

                    </Box>
                    {selectedParty.address && (
                      <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                        📍 {selectedParty.address}
                      </Typography>
                    )}
                  </Box>
                  <Button
                    variant="contained"
                    startIcon={<AddIcon />}
                    onClick={handleCreateOrder}
                    sx={{ borderRadius: 2 }}
                  >
                    Create Order
                  </Button>
                </Box>
              </CardContent>
            </Card>
          )}

          <Divider sx={{ my: 3 }} />

          {/* Enhanced Orders Management Section */}
          <PendingOrdersManager
            userId={currentUser.uid}
            onCreateOrder={handleCreateOrder}
            onEditOrder={handleEditOrder}
            onViewOrder={handleViewOrder}
            key={refreshTrigger} // This will trigger a refresh when refreshTrigger changes
          />

          {/* Create/Edit Order Form Dialog */}
          <CreateOrderForm
            open={showCreateForm}
            onClose={() => setShowCreateForm(false)}
            onSuccess={handleFormSuccess}
            editOrder={editOrder}
            userId={currentUser.uid}
          />

          {/* Legacy Delete Confirmation Dialog */}
          <ConfirmationDialog
            open={deleteConfirmOpen}
            onClose={handleCancelDelete}
            onConfirm={handleConfirmDelete}
            title="Confirm Order Deletion"
            message="Are you sure you want to delete this order? This action cannot be undone."
            confirmText="Delete"
            confirmColor="error"
          />
      </Container>
    </Box>
  );
}


export default function ModernOrdersPage() {
  return (
    <ModernThemeProvider>
      <VisuallyEnhancedDashboardLayout
        title="Orders"
        pageType="orders"
        enableVisualEffects={true}
        enableParticles={false}
      >
        <OrdersPage />
      </VisuallyEnhancedDashboardLayout>
    </ModernThemeProvider>
  );
}